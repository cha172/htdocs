
<?php $this->beginPage() ?>
<!DOCTYPE html>
        <?php $this->head();  ?>  
    <?php $this->beginBody() ?>
            <?php echo $content ; ?>
    <?php $this->endBody() ?>
</html>
<?php $this->endPage() ?>
