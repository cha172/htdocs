
<footer class="footer-content">
    2020 - <span id="copyright-year"></span> &copy;E-Tera. Created by <a href="#" target="_blank">E-Tera -  Sistem Informasi Tera</a>

</footer><!-- /.footer-content -->