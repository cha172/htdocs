<div class="content">
<?php
$img="../../images/logo.png";
echo '<img src="'.$img. '" width="600" height="800"';
?>
</div>